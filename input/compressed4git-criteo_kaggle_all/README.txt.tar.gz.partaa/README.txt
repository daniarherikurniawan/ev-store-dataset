Initially the criteo_kaggle_all.npz was kaggleAdDisplayChallenge_processed.npz; we rename it to be consistent with the folder name. 
